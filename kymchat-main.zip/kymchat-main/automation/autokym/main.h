//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Data.Bind.Components.hpp>
#include <Data.Bind.ObjectScope.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Edit.hpp>
#include <FMX.EditBox.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.ListBox.hpp>
#include <FMX.Memo.hpp>
#include <FMX.Memo.Types.hpp>
#include <FMX.MultiView.hpp>
#include <FMX.NumberBox.hpp>
#include <FMX.ScrollBox.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>

#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Memo.hpp>
#include <FMX.Memo.Types.hpp>
#include <FMX.ScrollBox.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.MultiView.hpp>
#include <FMX.NumberBox.hpp>
#include <FMX.Layouts.hpp>
#include "restthread.h"
#include <FMX.TabControl.hpp>
#include <REST.Client.hpp>
//---------------------------------------------------------------------------
class TMainWn : public TForm
{
  __published: // IDE-managed Components
    TStatusBar* StatusBar1;
    TPanel* KymPanel;
    TMemo* delKymRes;
    TSplitter* Splitter1;
    TMemo* delKymReq;
    TMultiView* MultiView1;
    TGroupBox* GroupBox11;
    TLabel* appLab;
    TComboBox* cbStyles;
    TComboBox* ComboBoxSymbology;
    TLabel* Label25;
    TLabel* lanLabel;
    TEdit* ScalesSetting;
    TLabel* sLabel5;
    TComboBox* PersonaCombo;
    TButton* Button1;
    TGroupBox* GroupBox1;
    TLabel* Label1;
    TButton* LogoutBut;
    TLabel* nnLabel3;
    TComboBox* modeComboBox5;
    TNumberBox* NumberBox1;
    TLabel* Label2;
    TLabel* Text1;
    TLabel* TextScale;
    TLabel* Label3;
    TTrackBar* ScaleTrack;
    TLabel* test_something;
    TLayout* MBLayout;
    TSpeedButton* MasterButton;
    TButton* GoBut;
    TLayout* ControlRoot;
    TSplitter* Splitter5;
    TEdit* Edit1;
    TLabel* Label4;
    TProgressBar* ProgressBar1;
    TTimer* Timer1;
    TTabControl* kymTab;
    TButton* Test;
    TButton* AddTab;
    TToolBar* ToolBar1;
    void __fastcall delKymReqKeyUp(TObject* Sender, WORD &Key,
        System::WideChar &KeyChar, TShiftState Shift);
	void __fastcall GoButClick(TObject* Sender);
	void __fastcall Timer1Timer(TObject* Sender);
	void __fastcall addTabButClick(TObject* Sender);
    void __fastcall TestClick(TObject* Sender);
    void __fastcall PersonaComboChange(TObject* Sender);
  private: // User declarations
	TRestThread* kymThread[10000]; 				//max of concurrent threads possible
	void DoRequest(int uid, int answerCount);
	int AddQuestionToList(String question, int threadno);
  public: // User declarations
  //todo - remove the limitations below by moving from array to stl::vector
	TTabItem* kymtab[10000];    				//max of 10000 tabs possible in app
	TMemo* kymUserReq[10000];   				//max of 10000 request memos (@1 per tab) in app
	TMemo* kymRes[10000];       				//max of 10000 response memos @(1 per tab) in app
	TStringList* questionList[10000];           //max of 10000 questionlists @(1 per tab) in app
	TStringList* kymConvIDs;    				//list of conversationIDs
	TStringList* csvRow[1000]; 					//max of 1000 rows in csv file
	__fastcall TMainWn(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainWn* MainWn;
//---------------------------------------------------------------------------
#endif


