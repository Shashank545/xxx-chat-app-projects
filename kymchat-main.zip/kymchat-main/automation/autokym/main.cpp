﻿//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TMainWn* MainWn;
//---------------------------------------------------------------------------
__fastcall TMainWn::TMainWn(TComponent* Owner) : TForm(Owner)
{
    MultiView1->Mode = TMultiViewMode::Drawer;
    kymConvIDs = new TStringList();
}
//---------------------------------------------------------------------------
void __fastcall TMainWn::delKymReqKeyUp(
    TObject* Sender, WORD &Key, System::WideChar &KeyChar, TShiftState Shift)

{
    if (Shift.Contains(ssShift)) {
        return;
    }
    //TMemo *m = static_cast<Sender>;
    if (Key == VK_RETURN) {
        //GoButClick(Sender);
        kymUserReq[kymTab->TabIndex]->Enabled = false;
        int answerID = AddQuestionToList(
            kymUserReq[kymTab->TabIndex]->Text, kymTab->TabIndex);
        DoRequest(kymTab->TabIndex, answerID);
    }
}
//---------------------------------------------------------------------------
void __fastcall TMainWn::GoButClick(TObject* Sender)
{
    //	if (GoBut->StyleLookup == "playtoolbutton") { //user manually started a test
    //		GoBut->Enabled = false;
    //		kymUserReq[kymTab->TabIndex]->Enabled = false;
    //		GoBut->StyleLookup = "pausetoolbutton";
    //		ProgressBar1->Visible = true;
    //		Timer1->Enabled = true;
    //		DoRequest(kymTab->TabIndex);
    //	} else { //user manually initiated cancel
    //		kymUserReq[kymTab->TabIndex]->Enabled = true;
    //		GoBut->StyleLookup = "playtoolbutton";
    //		kymUserReq[kymTab->TabIndex]->SetFocus();
    //		Timer1->Enabled = false;
    //		ProgressBar1->Value = 0;
    //		Label4->Text = "Cancelled";
    //		//cancel request
    //		kymThread[kymTab->TabIndex]->Terminate();
    //	}
}
//---------------------------------------------------------------------------
void TMainWn::DoRequest(int uid, int answerCount)
{
    GoBut->Enabled = true;
    Label4->Text = "Waiting...";
    ProgressBar1->Visible = true;
    Timer1->Enabled = true;
    kymThread[uid] = new TRestThread(
        false, uid, PersonaCombo->Text, kymConvIDs->Strings[uid], answerCount);
}
//---------------------------------------------------------------------------
void __fastcall TMainWn::Timer1Timer(TObject* Sender)
{
    if (ProgressBar1->Value == ProgressBar1->Max) {
        ProgressBar1->Value = 0;
    } else
        ProgressBar1->Value++;
}
//---------------------------------------------------------------------------
void __fastcall TMainWn::addTabButClick(TObject* Sender)
{
    int tcount = kymTab->TabCount;
    kymConvIDs->Add("");
    questionList[tcount] = new TStringList();
    //kymThread[tcount]->id = tcount;
    kymtab[tcount] = new TTabItem(this);
    kymtab[tcount]->Text = PersonaCombo->Text + " " + String(tcount);
    kymtab[tcount]->Parent = kymTab;
    kymUserReq[tcount] = new TMemo(this);
    //kymM[tcount]->PopupMenu = PopupMenu1;
    //kymM[tcount]->ReadOnly = true;
    kymUserReq[tcount]->WordWrap = true;
    kymUserReq[tcount]->Tag = tcount;
    kymUserReq[tcount]->Parent = kymtab[tcount];
    kymUserReq[tcount]->Align = TAlignLayout::Top;
    kymUserReq[tcount]->HideSelectionOnExit = false;
    kymUserReq[tcount]->OnKeyUp = delKymReqKeyUp;

    kymRes[tcount] = new TMemo(this);
    //kymM[tcount]->PopupMenu = PopupMenu1;
    kymRes[tcount]->ReadOnly = true;
    kymRes[tcount]->WordWrap = true;
    kymRes[tcount]->Tag = tcount;
    kymRes[tcount]->Parent = kymtab[tcount];
    kymRes[tcount]->Align = TAlignLayout::Client;
    kymRes[tcount]->HideSelectionOnExit = false;
    TSplitter* Splitter = new TSplitter(this);
    Splitter->Parent = kymtab[tcount];
    Splitter->Align = TAlignLayout::Top;
    kymTab->TabIndex = tcount;
}
//---------------------------------------------------------------------------

void __fastcall TMainWn::TestClick(TObject* Sender)
{
    TMemo* M = new TMemo(this);
    M->Lines->LoadFromFile("test.csv");
    M->Text =
        StringReplace(M->Text, "\r\n", "¬", TReplaceFlags() << rfReplaceAll);
    M->Text =
        StringReplace(M->Text, "¬¬", " ", TReplaceFlags() << rfReplaceAll);
    M->Text = StringReplace(
        M->Text, "¬", sLineBreak, TReplaceFlags() << rfReplaceAll);
    String dataS = M->Lines->Strings[0];
    M->Lines->Delete(0);
    for (int i = 0; i < 2; i++) {
        M->Text =
            StringReplace(M->Text, ",,", "", TReplaceFlags() << rfReplaceAll);
    }
    M->Lines->Insert(0, dataS);

    TStringList* colNames = new TStringList();
    for (int j = 0; j < M->Lines->Count; j++) {
        TStringList* sl;
        if (j == 0) {
            sl = colNames; //this is the lookup for each row
        } else {
            csvRow[j - 1] = new TStringList();
            sl = csvRow[j - 1]; //csvRow starts from zero
        }
        String dataS = M->Lines->Strings[j];

        //convert the csv into a stringlist data object
        int commaPos = dataS.Pos(",");
        int colpos = 0;
        while (commaPos > 1) {
            commaPos = dataS.Pos(",");
            String d = dataS.SubString(1, commaPos - 1);
            if (!commaPos) {
                d = dataS;
            }
            if (j == 0)
                sl->Add(d);
            else {
                sl->Add(d);
            }
            dataS = dataS.SubString(commaPos + 1, dataS.Length());
            colpos++;
            if (j && colpos == 2) {
                sl->Add(StringReplace(
                    dataS, "\"", "", TReplaceFlags() << rfReplaceAll));
                break;
            }
        }
    }
	//grab all the questions from the csv
	int firstID;
	for (int rowNo = 1; rowNo < M->Lines->Count - 1; rowNo++) {
        int colno = colNames->IndexOf("question");
        int personaID = colNames->IndexOf("persona");
        int qno = colNames->IndexOf("number");

		String persona = csvRow[rowNo - 1]->Strings[personaID];
        int index = PersonaCombo->Items->IndexOf(persona);

        String question = csvRow[rowNo - 1]->Strings[colno];
		int qID = csvRow[rowNo - 1]->Strings[qno].ToIntDef(0);
		int nextqID = -1;
        if (qID == 1) {
            if (PersonaCombo->ItemIndex == index) {
                addTabButClick(NULL);
            } else {
                PersonaCombo->ItemIndex = index;
            }
            firstID = AddQuestionToList(question, kymTab->TabIndex);
        } else {
            AddQuestionToList(question, kymTab->TabIndex);
		}
		if (rowNo < M->Lines->Count - 2) nextqID = csvRow[rowNo]->Strings[qno].ToIntDef(0);
		if (qID >= nextqID) {
			DoRequest(kymTab->TabIndex, firstID);
		}
    }
}
//---------------------------------------------------------------------------
int TMainWn::AddQuestionToList(String question, int threadno)
{
    int answerID = questionList[threadno]->Count;
    question = StringReplace(
        Trim(question), sLineBreak, " ", TReplaceFlags() << rfReplaceAll);
    questionList[threadno]->Add(question);
    return answerID;
}
//---------------------------------------------------------------------------

void __fastcall TMainWn::PersonaComboChange(TObject* Sender)
{
    AddTab->Visible = true;
    addTabButClick(Sender);
}
//---------------------------------------------------------------------------

