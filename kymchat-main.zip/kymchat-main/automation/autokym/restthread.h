//---------------------------------------------------------------------------

#ifndef restthreadH
#define restthreadH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <REST.Client.hpp>
#include <REST.Types.hpp>
#include <System.SysUtils.hpp>
#include <DateUtils.hpp>
#include <REST.Client.hpp>
#include <REST.Types.hpp>
#include <Data.Bind.Components.hpp>
#include <Data.Bind.ObjectScope.hpp>
//---------------------------------------------------------------------------
class TRestThread : public TThread
{
  private:
    String conversationID;
    TRESTClient* RESTClient;
    TRESTRequest* RESTRequest;
    TRESTResponse* RESTResponse;
    int id;
    String persona;
    int answerCount;
	String question;
	String error;
	void __fastcall UpdateGUI();
    void __fastcall UpdateTab();
	void __fastcall GetQuestion();
	void __fastcall ErrorMsg();
	void __fastcall RESTRequest1HTTPProtocolError(TCustomRESTRequest *Sender);
  protected:
    void __fastcall Execute();
  public:
    void DoRequest();
    __fastcall TRestThread(bool CreateSuspended, int _id, String _persona,
        String _conversationID, int _answerCount);
};
//---------------------------------------------------------------------------
#endif

