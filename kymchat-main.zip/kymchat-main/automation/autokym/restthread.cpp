//---------------------------------------------------------------------------

#include <System.hpp>
#pragma hdrstop
#include "main.h"
#include "restthread.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------
void __fastcall TRestThread::GetQuestion()
{
    question = MainWn->questionList[id]->Strings[answerCount];
    if (MainWn->kymUserReq[id]->Text == "") { //auto filled
        MainWn->kymUserReq[id]->Text = question;
        MainWn->kymUserReq[id]->GoToTextEnd();
    }
    MainWn->kymtab[id]->Text = "[" + String(answerCount + 1) + " of " +
                               String(MainWn->questionList[id]->Count) + "]...";
}
//---------------------------------------------------------------------------
void __fastcall TRestThread::UpdateTab()
{
    MainWn->kymtab[id]->Text = persona + " " + String(id);
}
//---------------------------------------------------------------------------
void __fastcall TRestThread::UpdateGUI()
{
	answerCount++;
	TJSONObject* JSON1 =
		(TJSONObject*)TJSONObject::ParseJSONValue(RESTResponse->JSONText);

	TJSONPair* pair2 = JSON1->Get("conversationID");
	if (pair2) {
		conversationID = pair2->JsonValue->Value();
		MainWn->kymConvIDs->Strings[id] = conversationID;
	}
	TJSONPair* pair3 = JSON1->Get("responseTimestamp");
	if (pair3) {
		String resTS = pair3->JsonValue->Value();
		TJSONPair* pair4 = JSON1->Get("queryTimestamp");
		if (pair4) {
			String reqTS = pair4->JsonValue->Value();
			TDateTime dtend = ISO8601ToDate(resTS);
			TDateTime dtstart = ISO8601ToDate(reqTS);
			TDateTime dt = dtend - dtstart;
			unsigned short hour, min, sec, msec;
			dt.DecodeTime(&hour, &min, &sec, &msec);
			TJSONPair* pair1 = JSON1->Get("response");
			if (pair1) {
				MainWn->kymRes[id]->Lines->Add(
					"Question " + String(answerCount) + ":");
				MainWn->kymRes[id]->Lines->Add("=============");
				MainWn->kymRes[id]->Lines->Add(MainWn->kymUserReq[id]->Text);
				MainWn->kymRes[id]->Lines->Add("");
				MainWn->kymRes[id]->Lines->Add("Answer " + String(answerCount) +
											   " [" + String(sec) + "." +
											   String(msec) + " sec]");
				MainWn->kymRes[id]->Lines->Add("=============");
				//MainWn->kymRes[id]->Lines->Add(question);//Trim(MainWn->kymReq[id]->Text));
				MainWn->kymRes[id]->Lines->Add(pair1->JsonValue->Value());
				MainWn->kymRes[id]->Lines->Add("");
				MainWn->kymRes[id]->Lines->Add("");
            }
        }
    }
	MainWn->kymUserReq[id]->Lines->Clear();
	MainWn->GoBut->StyleLookup = "playtoolbutton";
	MainWn->kymUserReq[id]->Enabled = true;
	MainWn->Timer1->Enabled = false;
	MainWn->ProgressBar1->Value = 0;
	MainWn->ProgressBar1->Visible = false;
	MainWn->kymRes[id]->GoToTextEnd();
	MainWn->Label4->Text = "Finished";
	MainWn->kymUserReq[id]->SetFocus();
}
//---------------------------------------------------------------------------

__fastcall TRestThread::TRestThread(bool CreateSuspended, int _id,
    String _persona, String _conversationID, int _answerCount) :
    TThread(CreateSuspended)
{
    id = _id;
    persona = _persona;
    conversationID = _conversationID;
	answerCount = _answerCount;
    FreeOnTerminate = true;
    RESTClient = new TRESTClient(Application);
	RESTRequest = new TRESTRequest(Application);
	RESTRequest->OnHTTPProtocolError = RESTRequest1HTTPProtocolError;
    RESTResponse = new TRESTResponse(Application);
    RESTClient->BaseURL = "https://kym-dev-apims.azure-api.net/v1/query";
    RESTRequest->Client = RESTClient;
    RESTRequest->Response = RESTResponse;
    RESTRequest->Method = TRESTRequestMethod::rmPOST;
    RESTRequest->AddParameter(
        "Subscription-Key", "Enter subscription key here");
}
//---------------------------------------------------------------------------
void __fastcall TRestThread::Execute()
{
    DoRequest();
}
//---------------------------------------------------------------------------
void __fastcall TRestThread::ErrorMsg() {

				answerCount++;
				MainWn->kymRes[id]->Lines->Add(
					"Question " + String(answerCount) + ":");
				MainWn->kymRes[id]->Lines->Add("=============");
				MainWn->kymRes[id]->Lines->Add(MainWn->kymUserReq[id]->Text);
				MainWn->kymRes[id]->Lines->Add("");
				MainWn->kymRes[id]->Lines->Add("Answer ");// + String(answerCount) + " [" + String(sec) + "." + String(msec) + " sec]");
				MainWn->kymRes[id]->Lines->Add("=============");
				MainWn->kymRes[id]->Lines->Add(error);
				MainWn->kymRes[id]->Lines->Add("");
				MainWn->kymRes[id]->Lines->Add("");
}
//---------------------------------------------------------------------------
void __fastcall TRestThread::RESTRequest1HTTPProtocolError(TCustomRESTRequest *Sender)
{
	error = "a http protocol error occurred";
	Synchronize(ErrorMsg);
}
//---------------------------------------------------------------------------
void TRestThread::DoRequest()
{
	while (answerCount < MainWn->questionList[id]->Count) {
		Synchronize(GetQuestion);

		String conv = "";
		if (conversationID != "") {
			conv = ",\"conversationID\":\"" + Trim(conversationID) + "\"";
		}
		RESTRequest->Params->Delete("body");
		String message2 =
			"{\"query\":\"" + question + /*s->Strings[i]*/
			+"\",\"emailID\":\"user@kpmg.com.au\",\"persona\":\"" + persona +
			"\"" + conv + "}";

		RESTRequest->AddParameter(
			"body", message2, TRESTRequestParameterKind::pkREQUESTBODY);
		RESTRequest->Params->Items[1]->ContentTypeStr = ctAPPLICATION_JSON;
		try {
			RESTRequest->Execute();
		}
		catch(Exception& e) {  //todo: needs testing
			error = e.Message;
			Synchronize(ErrorMsg);
		}

		Synchronize(UpdateGUI);
    }
    Synchronize(UpdateTab);
}
//---------------------------------------------------------------------------

