from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import time
import pandas as pd
from datetime import datetime
from webdriver_manager.chrome import ChromeDriverManager

# Code to start the browser
service = Service(executable_path=ChromeDriverManager().install())
chrome_options = webdriver.ChromeOptions()
driver = webdriver.Chrome(service=service, options=chrome_options)
driver.maximize_window()
driver.get('https://kymdev.kpmg.com.au/')

wait = WebDriverWait(driver, 240)
wait.until(EC.presence_of_element_located((By.XPATH,'//*[@id="i0116"]')))
login = driver.find_element(By.XPATH,'//*[@id="i0116"]')
login.send_keys("gpatil1@kpmg.com.au")
login.send_keys(Keys.RETURN)
wait.until(EC.presence_of_element_located((By.XPATH,'//*[@id="react-joyride-step-0"]/div/div/div/div[2]/div/button')))

handle_tour = driver.find_element(By.XPATH,'//*[@id="react-joyride-step-0"]/div/div/div/div[2]/div/button')
handle_tour.click()
sustania = driver.find_element(By.XPATH,"//button[contains(@class,'pas-open-personas')]").click()
time.sleep(2)
driver.find_element(By.XPATH,"//div[contains(@class,'pas-open-persona-Solutions')]").click()
answers = []


dataset = pd.read_excel('Solutions.xlsx')
column_data = dataset['Prompts']
question = [value.replace("\n", ' ') for value in column_data]

def save_iteration_number(iteration):
    with open("iterationsolutions.txt", "w") as f:
        f.write(str(iteration))

def read_saved_iteration_number():
    try:
        with open("iterationsolutions.txt", "r") as f:
            return int(f.read())
    except FileNotFoundError:
        return 0

start_iteration = read_saved_iteration_number()

# Initialize the answers list outside the loop
answers = []

# Loop through the questions starting from the saved iteration
for i in range(start_iteration, len(question)):
    try:
        test = driver.find_elements(By.XPATH,'//div[contains(@class,"pas-message-input")]//textarea')[0]
        test.click()
        test.clear()
        test.send_keys(question[i])
        test.send_keys(Keys.RETURN)
        wait = WebDriverWait(driver, 240)
        wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'pas-conversation-message')))
        wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, "pas-conversation-message-loading")))

        # Get the last response element
        test_element = driver.find_elements(By.CLASS_NAME, 'pas-conversation-message')
        last_elm = test_element[-1]
        content = last_elm.text
        answers.append(content)
        current_datetime = datetime.now()
        execution_time = current_datetime.strftime("%Y %B %d %H %M %S")
        print(f'{execution_time } Test case number {i+1} executed.')
        

        # Restart a new conversation
        driver.find_element(By.CLASS_NAME, 'pas-start-new-conversation').click()
    except Exception as e:
        print(f"An error occurred on iteration {i}: {e}")
        save_iteration_number(i)
        break

# Create a DataFrame using the answers list
combined_df = pd.DataFrame({'Question': question[start_iteration:], 'Answer': answers})

# Write the combined DataFrame to an Excel file
combined_filename = current_datetime.strftime("Solutions_dev_%Y%B%d%H%M%S.xlsx")
combined_df.to_excel(combined_filename, index=False)

# Close the browser at the end
driver.quit()
