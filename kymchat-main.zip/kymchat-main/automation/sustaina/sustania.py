import os
import re
import time
from datetime import datetime
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import pyperclip
import pandas as pd

# Load environment variables
load_dotenv()

# Code to start the browser
service = Service(executable_path=ChromeDriverManager().install())
chrome_options = webdriver.ChromeOptions()
driver = webdriver.Chrome(service=service, options=chrome_options)
driver.maximize_window()
driver.get(os.getenv("KYMCHAT_URL"))
wait = WebDriverWait(driver, 120)
wait.until(EC.presence_of_element_located((By.XPATH, '//*[ @id="i0116" ]')))
login = driver.find_element(By.XPATH, '//*[ @id="i0116" ]')
login.send_keys(os.getenv("KYMCHAT_USER_EMAIL"))
login.send_keys(Keys.RETURN)


wait.until(EC.presence_of_element_located((By.XPATH, '//*[ @id="react-joyride-step-0" ]/div/div/div/div[ 2 ]/div/button')))
handle_tour = driver.find_element(By.XPATH, '//*[ @id="react-joyride-step-0" ]/div/div/div/div[ 2 ]/div/button')
handle_tour.click()

sustania = driver.find_element(By.XPATH,"//button[contains(@class,'pas-open-personas')]").click()
time.sleep(10)
# wait.until(EC.presence_of_element_located(By.XPATH,"//div[contains(@class,'pas-open-persona-Sustaina')]"))
driver.find_element(By.XPATH,"//div[contains(@class,'pas-open-persona-Sustaina')]").click()

dataset = pd.read_excel(os.getenv("PROMPT_FILE_PATH"))
column_data = dataset[ "Prompts" ]
question = [ value.replace("\n", " ") for value in column_data ]

def save_iteration_number(iteration):
    with open("iteration_sustaina.txt", "w") as f:
        f.write(str(iteration))

def read_saved_iteration_number():
    try:
        with open("iteration_sustaina.txt", "r") as f:
            return int(f.read())
    except FileNotFoundError:
        return 0

counter = 0
start_iteration = read_saved_iteration_number()

# Create initial Excel file to save data
combined_filename = datetime.now().strftime("Sustaina_Prompts_Dev_Results_%Y-%m-%d %HHrs-%MMins-%SSecs.xlsx")
start_time = datetime.now()
data_columns = [ "Prompt", "Response", "Source 1", "Source 2", "Source 3", "Source 4", "Source 5", "Source 6", "Source 7" , "Source 8","Source 9","Source 10" ]
results_df = pd.DataFrame(columns=data_columns)
results_df.to_excel(combined_filename, index=False)

# Loop through the questions starting from the saved iteration
for i in range(start_iteration, len(question)):
    try:
        input_field = driver.find_element(By.XPATH, '//div[ contains(@class,"pas-message-input") ]//textarea')
        input_field.click()
        input_field.clear()
        input_field.send_keys(question[ i ])
        input_field.send_keys(Keys.RETURN)
        wait.until(EC.presence_of_element_located((By.CLASS_NAME, "pas-conversation-message")))
        wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, "pas-conversation-message-loading")))
        time.sleep(2)  # Pause to allow clipboard to update
        # Click on the copy to clipboard button and parse the clipboard content
        driver.find_element(By.CLASS_NAME, "pas-copy-to-clipboard").click()
        clipboard_data = pyperclip.paste()
        extracted_urls = re.findall(r'https?://\S+|www\.\S+', clipboard_data)
        url_list = [ url.strip("),'") for url in extracted_urls ]

        # Ensure url_list has at least 7 elements, adding empty strings if necessary
        
        unique_list =[]
        for item in url_list:
            if item not in unique_list:
                unique_list.append(item)
        url_list = unique_list
        url_list += [ ' ' ] * (10 - len(url_list))
        # Creating a DataFrame with the question, response, and Sources
        iteration_df = pd.DataFrame({
            "Prompt": [ question[i] ], # Assuming 'question' is a list, indexing the first element
            "Response": [ clipboard_data ],
            "Source 1": [ url_list[ 0 ] ],
            "Source 2": [ url_list[ 1 ] ],
            "Source 3": [ url_list[ 2 ] ],
            "Source 4": [ url_list[ 3 ] ],
            "Source 5": [ url_list[ 4 ] ],
            "Source 6": [ url_list[ 5 ] ], 
            "Source 7": [ url_list[ 6 ] ],
            "Source 8": [ url_list[ 7 ] ],
            "Source 9": [ url_list[ 8 ] ],
            "Source 10": [ url_list[ 9 ] ],
        })

        # Concatenate the iteration DataFrame to the results_df DataFrame
        results_df = pd.concat([ results_df, iteration_df ], ignore_index=True)

        # Write the single row DataFrame to the Excel file immediately
        with pd.ExcelWriter(combined_filename, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
            iteration_df.to_excel(writer, header=False, index=False, startrow=writer.sheets[ 'Sheet1' ].max_row)

        # Save the current iteration number
        save_iteration_number(i + 1)  # save next iteration number to continue from

        # Restart a new conversation
        driver.find_element(By.CLASS_NAME, "pas-start-new-conversation").click()

        # Print the execution time
        current_datetime = datetime.now()
        execution_time = current_datetime.strftime("%Y-%m-%d %HHrs:%MMins:%SSecs")
        print(f"{execution_time} Prompt Number {i+1} Executed.")
        counter +=1
        # Check if the last iteration has been completed
        if i == len(question) - 1:
            # Delete the iteration_integra.txt file
            if os.path.exists("iteration_sustaina.txt"):
                os.remove("iteration_sustaina.txt")
                end_time = datetime.now()
                time_difference = end_time - start_time
                hours = time_difference.seconds // 3600
                minutes = (time_difference.seconds // 60) % 60
                seconds = time_difference.seconds % 60
                counter +=1
                
                print(f"All test cases are now executed.\nTotal Execution Time for {counter-1} Prompts: {hours} hours : {minutes} minutes : {seconds} seconds")
    except Exception as e:
        print(f"An error occurred on iteration {i}: {e}")
        save_iteration_number(i)  # save this iteration number to retry from
        raise  # add a raise here to not miss out on the original stack trace of the exception

# Close the browser at the end
driver.quit()