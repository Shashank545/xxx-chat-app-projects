---
name: "✨ New Feature or Enhancement"
about: Create a new app feature or enhancement.
title: ''
labels: Enhancement, Feature
assignees: ''

---

# Summary

[Purpose and intent of the new feature/enhancement]

## User Stories

[List the user stories of the new feature/enhancement]

# Criteria

[Individual functional points of the new feature/enhancement]

## Testing Criteria

[High-level criteria to achieve test acceptance]

## Out of Scope

[Items not to include or update]

## References

[Links to related issues]
