---
name: "\U0001F41E Defect report"
about: Something isn't working as expected? Submit a new defect report.
title: ''
labels: Defect
assignees: ''

---

### Description

[A clear and concise description of what the defect is]

### Prerequisites

[Prompt setup or similar before the specific steps to replicate the defect are executed]

### Steps

[Number steps to reproduce the issue]
[1. Go to '...']
[2. Click on '....']
[3. Scroll down to '....']

### Expected Behaviour

[Describe the expected outcome]

### Actual Behaviour

[Describe the actual outcome]

### Workaround

[List any workarounds that can resolve the defect or lessen the impact/priority]

### Environment

**Build: [KymChat app build number]**

**Desktop (please complete the following information):**
 - OS: [e.g. MacOS Ventura]
 - Browser [e.g. Chrome, Safari]
 - Version [e.g. 112]

### Screen Captures

[If applicable, add screenshots to help explain the defect]

### References

[Links to related issues]
