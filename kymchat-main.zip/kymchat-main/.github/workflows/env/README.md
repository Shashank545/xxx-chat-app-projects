<a name="readme-top"></a>

<!-- OUR PROJECT LOGO -->
<div align="center">
  <img src="/.github/images/KYM-assets003-07-200x133.png" alt="Logo">
  <h3 align="center">KymChat</h3>
</div>

# Environment deployment - KymChat Azure Infrastructure Setup

**Templates:** ARM and Bicep

## Azure Deployment

Sample pipelines have been created to assist with deployment for sandbox and memberfirm environments. The oneclick.yml, azure-pipelines.yml and bicep-infrastructure.yml can be used as a base with parameter environments being set through the variables. 
