<a name="readme-top"></a>

<!-- OUR PROJECT LOGO -->
<div align="center">
  <img src=".github/images/KYM-assets003-07-200x133.png" alt="Logo">
  <h3 align="center">KymChat</h3>
  <p align="center">
    KymChat is KPMG’s internal Generative AI agent.
    <br />
    <a href="#architecture"><strong>Explore the architecture »</strong></a>
    <br />
    <br />
    <a href="../../issues/new?assignees=&labels=Defect&template=%F0%9F%90%9E-defect-report.md&title=">Something isn't working as expected? Submit a new defect report.</a>
    ·
    <a href="../../issues/new?assignees=&labels=Enhancement%2C+Feature&template=%E2%9C%A8-new-feature-or-enhancement.md&title=">Request a new feature or enhancement</a>
  </p>
</div>

<!-- TABLE OF CONTENTS -->

<details>
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#product-vision">Product Vision</a>
      <ul>
        <li><a href="#features">Features</a></li>
      </ul>
    </li>
    <li>
      <a href="#architecture">Architecture</a>
      <ul>
        <li><a href="#how-does-kymchat-work">How does KymChat work?</a></li>
        <li><a href="#azure-infrastructure-setup">Azure Infrastructure Setup</a></li>
        <li><a href="#dependencies-installation-and-usage">Dependencies, Installation and Usage</a></li>
      </ul>
    </li>
    <li><a href="#roadmap">Roadmap</a></li>
    <li><a href="#contributing">Contributing</a></li>
    <li><a href="#license">License</a></li>
  </ol>
</details>

<!-- ABOUT KYMCHAT -->

## Product Vision

KymChat, our internal ChatGPT product, aims to revolutionise the way KPMG communicates and collaborates, providing an intelligent, intuitive and userfriendly AI platform that streamlines discoverability, improves productivity and fosters a culture of innovation and community.

By leveraging the power of our AI technology, we strive to make content generation frictionless, allowing employees to work smarter, faster and better
together.

![Image](/.github/images/chat-400.png?raw=true)

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Benefit Statement and Development Principles

### Compliance with Acceptable Use Policy

1. Single Sign On (SSO) and identity federation
   - Only authenticated users have access with 2 or 3 authentication factors.
2. Data encryption
   - Data in-transit and at-rest are encrypted.
3. Data access control
   - Data are accessed through role-based access control.
   - Audit trails are maintained to ensure data accesses are fully traceable.
4. Data lifecycle
   - Data are published only when complete, accurate and appropriate.

### Knowledge segmentation

Knowledge sets are segmented to ensure factual consistency and reliability.
Segmentation is achieved through the creation of personas that provide:

- A dedicated user interface and API parameter
- A dedicated MongoDB collection for semantic search
- A dedicated set of prompt samples related to the knowledge being queried

### Contextualisation and performance

The meaning and context of unstructured documents are captured by vector embeddings. Semantic search is performed for every query (if setup at the persona level) to deliver more relevant and accurate results in a shorter execution time.

### Logging and feedback loop

All prompts written by users are logged:

- To help identify issues with machine learning and the interaction flow.
- To monitor user behaviour, enforce accountability and facilite compliance and security auditing.
- To provide a personalised experience by allowing the user to tailor subsequent prompts.
  Users can provide feedbacks on the results delivered.

### Creation and refresh of knowledge sets in bulk

A web crawler is available to ingest content from pages using the sitemap of a website. It can run on a timer to refresh the pages recently modified.

### Usage reporting

Standards dashboard allow the monitoring of usage of the platform.

- No. of users
- No. of requests
- Key prompts
- Entities and categories queried
- Cost analysis

### Education

Prompt samples are provided for the users to learn how to interact effectively with AI, improve their experience and the results they get.

## Features

KymChat provides the following features:

- Web UX and Q&A interfaces
  - Citations, Single Sign-On (Azure AD)
- Integration into Azure Cosmos DB for MongoDB vCore and Azure OpenAI Service
- Updated Retrieval Augmented Generation pattern (orchestration of data preparation, prompt construction and integration between model (ChatGPT) and retriever (Azure Cosmos DB for MongoDB vCore)
- Web crawler to ingest content from webpages for search index
- PowerBI reporting for management reporting on the service

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- ARCHITECTURE -->

## Architecture

KymChat implements Azure Cosmos DB vector search and Azure OpenAI Service to provide a ChatGPT-like experience over KPMG data using the Retrieval Augmented Generation pattern. It uses Azure OpenAI Service to access the ChatGPT model (currently _GPT-4_), and Azure Cosmos DB for MongoDB vCore for vector searching and retrieval. The solution architecture is represented by this diagram:

![Image](/.github/images/KymChatSolutionDesign.png?raw=true)

<!-- HOW-DO-KYMCHAT-WORK -->

### How does KymChat work?

#### Data Ingestion (generating vectors)

Vectors are generated in an Azure Function containing a Python loader. Vector generation starts with the data loading for KymChat which loads KPMG knowledge into an Azure Data Lake. The Azure Function calls Azure OpenAI's embedding API and passes the entire document to it. The returned vectorized data are persisted to Azure Cosmos DB for MongoDB vCore. In summary, this process performs the following steps:

1. **Web Crawler:** KymChat's web crawler ingests KPMG knowledge into an Azure Data Lake.
2. **Vector Generation:** KymChat’s data loader reads the data from the Azure Data Lake and calls Azure OpenAI to retrieve the embeddings.
3. **Saving the Embeddings:** The embeddings are persisted into Azure Cosmos DB for MongoDB vCore.

#### Processing (searching vectors and returning a response from Azure OpenAI)

KymChat implements an updated Retrieval Augmented Generation pattern (orchestration of data preparation, prompt construction and integration between model (ChatGPT) and retriever (Azure Cosmos DB for MongoDB vCore)). In the KymChat UX a user starts a new chat session then types in a question. The text is sent to Azure OpenAI's embeddings API to generate vectors on it. The vectors are then used to perform a vector search on Azure Cosmos DB for MongoDB vCore. The query response which includes the original source data is then sent to Azure OpenAI to generate a completion which is then passed back to the user as a response. In summary, this process performs the following steps:

(referencing the _Step Numbers_ in the above architecture diagram)

1. **Prompt Entry:** Using a web browser, the user visits KymChat and enters a prompt or questions into the provided input field.
2. **Request Routing:** The prompt is first sent to the Azure Application Gateway, which routes the request to the React web application.
3. **Request Processing:** The React web application send the user's input to the backend API container for processing.
4. **Prompt Embeddings Query:** KymChat’s backend (API container) sanitises the prompt and then calls Azure OpenAI to retrieve the embeddings of the prompt.
5. **Prompt Embeddings Results:** The embeddings for the user prompt are returned from Azure OpenAI.
6. **Vector Search:** A vector search is performed on Azure Cosmos DB for MongoDB vCore, searching the knowedge embeddings (created from the Data Ingestion) with the prompt embeddings.
7. **Vector Results:** The top 5 vecotor results are retained.
8. **Conversational Context:** Retrieve the historical conversation thread (if available).
9. **Model Interaction:** The system prompt + user prompt + historical conversation + embeddings + vector results are sent to Azure OpenAI.
10. **Response Generation:** Azure OpenAI generates the result. If no embeddings/vector results are provided or if the knowledge is of no help, Azure OpenAI will default to its own GPT knowledge.
11. **Response Delivery:** The backend API container sends the processed response back to the React web application.
12. **Response Routing:** The prompt is sent back via the Azure Application Gateway.
13. **Presentation:** The React web application presents the response to the user.
14. **Conversation Logging:** The latest conversation prompt/response is persisted into the conversation history.
15. **Power BI Reporting:** Analyse and visualise KymChat usage, including users and requests per hour, summarised view, key phrases, entity words, cost analysis and feedback insights.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- SETUP -->

### [Azure Infrastructure Setup](/azure-infrastructure)

The purpose of these setup steps are to build a new KymChat enivironment which can be adapted where needed to meet your requirements. The current networking has implemented resources behind a vnet and private endpoints.

**Supported Cloud environment:** Microsoft Azure

**CI/CD delivery platform:** GitHub actions & ADO

#### Azure Deployment

If you\'re wanting to deploy KymChat into your own environment please use the arm templates provided, both GitHub actions and ADO deployment methods are available. Please follow the steps below for successful deployment. ARM templates are stored within the following folders.

| Description                           | Folder                                                 | Module                                                                                    |
| ------------------------------------- | ------------------------------------------------------ | ----------------------------------------------------------------------------------------- |
| ARM templates for resource deployment | `kymchat/azure-infrastructure/ARM`                     | https://github.com/KPMG-AU/kymchat/tree/main/azure-infrastructure/ARM                     |
| Github actions pipelines              | `kymchat/.github/workflows/azure-infrastructure.yml`   | https://github.com/KPMG-AU/kymchat/blob/main/.github/workflows/azure-infrastructure.yml   |
| ADO pipelines                         | `kymchat/azure-infrastructure/ARM/azure-pipelines.yml` | https://github.com/KPMG-AU/kymchat/blob/main/azure-infrastructure/ARM/azure-pipelines.yml |

**Deployment Methods**

- This repository contains both github actions and ADO yaml files which can be used for solution deployment depending on your deployment method preference. The code is configured to use actions, with the yaml files being stored in the .github folder under actions within azure-infrastructure.yml. The ado deployment code is stored within the azure-infrastructure folder.

- GitHub actions version, see github actions pipelines in above table
- Azure DevOps (ADO) version, see ADO pipelines in above table

Both pipelines can be triggered by different branches, depending on the environment you're deploying to or what change you're making. The default is main, but you can add the additional ones under branches:, include:, -branch_name

<!-- INSTRUCTIONS -->

### Dependencies, Installation and Usage

For instructions on KymChat's dependencies, installation steps and usage, execute the steps in the following `README` files:

| Folder                                                     | Module                                                                       |
| ---------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `kymchat/docker-api/`                                      | [Docker API](/docker-api)                                                    |
| `kymchat/back-end/`                                        | [Vector Database](/back-end)                                                 |
| `kymchat/back-end/AzureFunctions/CSharpETL/`               | [C# ETL](/back-end/AzureFunctions/CSharpETL)                                 |
| `kymchat/back-end/AzureFunctions/PythonCrawlerDockerImage` | [Python Selenium crawler](/back-end/AzureFunctions/PythonCrawlerDockerImage) |
| `kymchat/front-end/`                                       | [KymChat Front-End](/front-end)                                              |
| `kymcat/power-bi/`                                         | [KYMGPTDB and PBI](/power-bi)                                                |

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## How other service integrate with kymchat

Please refer to this [doc](https://github.com/KPMG-AU/kymchat/wiki/Onboarding-services-to-consume-Kymchat-api)

<!-- ROADMAP -->

## Roadmap

If you are interested in seeing what features are coming up and more importantly, what you’ll be able to do with the KymChat going forward, download the [KymChat Roadmap](/.github/files/KymChat-Roadmap.pdf). The Roadmap is the product’s north star guiding the product vision, and detailing future features and supported use cases.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- CONTRIBUTING -->

## Contributing

Contributions are what make KPMG Code such an amazing place to learn, inspire, and create. Any contributions you make are **greatly appreciated**.

If you have a suggestion that would make this better, please fork the repo and create a pull request.
Don't forget to give the project a star! Thanks again!

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- LICENSE -->

## License

Distributed under the [**KPMG Open Source (KOS) License Type 1**](https://handbook.code.kpmg.com/KPMG-Code/GitHub/Collaboration/KOS-licenses/). See [LICENSE](/LICENSE) for more information.

<p align="right">(<a href="#readme-top">back to top</a>)</p>
