<a name="readme-top"></a>

<!-- OUR PROJECT LOGO -->
<div align="center">
  <img src="/.github/images/KYM-assets003-07-200x133.png" alt="Logo">
  <h3 align="center">KymChat</h3>
</div>

# KymChat Azure Infrastructure Setup

**Supported Cloud environment:** Microsoft Azure

**CI/CD delivery platform:** ADO & GitHub actions 

## Azure Deployment

If you\'re wanting to deploy KymChat into your own environment please use the arm templates/ bicep provided, both GitHub actions and ADO deployment methods are available. To deploy the infrastructure and application code through ADO, please use the files found within the _yaml/infra and _yaml/application folders.

| Description                           | Folder                                                 | Module                                                                                    |
| ------------------------------------- | ------------------------------------------------------ | ----------------------------------------------------------------------------------------- |
| Infrastructure - ADO pipelines                         | `kymchat/azure-infrastructure/ARM/_yaml/infra/azure-pipelines.yml` | https://github.com/KPMG-AU/kymchat/blob/main/azure-infrastructure/ARM/_yaml/infra/azure-pipelines.yml |
| Application - ADO pipelines                         | `kymchat/azure-infrastructure/ARM/_yaml/application/*` | https://github.com/KPMG-AU/kymchat/blob/main/azure-infrastructure/ARM/_yaml/application/* |


## Before you begin

To deploy the code into a new environment the following elements are required:

- A **service principal** which has owner/contributor access to your subscription and resource group. If you want to enable SSO, you can permit the user.read api permission which requires a user to have an ad account within your tenant to authenticate. Please also redirect the URIs under the authentication page to your frontend apps url using the single page application option.

- **subscription** - please update the subscription name and id in the relevant parameter files, e.g. the dev-parameters.json in the private endpoints folder. Currently the arm templates require the subscription name and id to be hard coded in the parameter file so that the resource can be built. The code has been deployed in a number of memberfirms each having their own parameter file for the resources, please use this as a standard. 

- **secrets** - Create a new library or environment and save your environment secrets, these include the following:

  - _Infrastructure secrets_
    - AZURE_CREDENTIALS - used by github for service principal access, saved in json format and stores: clientId, clientSecret, subscriptionId and tenantId
    - AZURE_RG_NAME - Resource group name
    - AZURE_SUBSCRIPTION_ID - Azure subscription id
    AZURE_SP_TENANT_ID - Tenant ID
    AZURE_TENANT_ID - Tenant ID (duplicate from above)
    - AZURE_CLIENT_ID - Service principal client id
    - AZURE_CLIENT_SECRET - Service principal client id
  - _Docker API secrets_
    - AZURE_ACR_CONTAINER - Acr container name - ai-workbench-gpt-api
    - AZURE_ACR_NAME - Acr resource name - ausazpowerkymctacr01.azurecr.io
    - AZURE_ACR_PASSWORD - Stored under access keys in acr
    - AZURE_ACR_USERNAME - Stored under access keys in acr
  - _Frontend secrets_
    - AZURE_FRONTEND_WA_NAME - Frontend end linux app service
    - AZURE_FRONTEND_WA_PUBLISHPROFILE - Frontend end publish profile – from azure portal app overview page
    - VITE_AAD_CLIENT_ID - Service principal client id
    - VITE_AAD_TENANT_ID - Service principal tenant id 
    - VITE_BASE - Front end app base
    - VITE_API_BASE_URL- AZURE_BACKEND_WA url
    - VITE_WS_BASE_URL: api url but using the following structure ws://ausazdev-kymct-api01.azurewebsites.net
    - VITE_CLIENT_SECRET - Service principal client secret
  - _Backend secrets_
    - AZURE_BACKEND_WA_NAME - API container app service
    - AZURE_CRAWLER_FA_NAME
    - AZURE_CRAWLER_FA_PUBLISHPROFILE
  - _Function app secrets_
    - AZURE_CRAWLER_FA_NAME - Python crawler function app – windows stack
    - AZURE_CRAWLER_FA_PUBLISHPROFILE - Python crawler function app – windows stack
    - AZURE_TEXT_FA_NAME - Text analytics function app – linux stack
    - AZURE_TEXT_FA_PUBLISHPROFILE - Text analytics function app publish profile


## Directing Application Code

Once you've deployed the resources above you will need to redirect the application yaml files to your new subscription and resource group. The secrets stored above in **secrets** will provide access to these resources and allow you to deploy the application code and build your own version of kymchat.

There are 5 elements of the application code, these being:

- frontend.yml - deployed using the pipeline-frontend.yml (this is the existing pipeline file your ADO pipeline should be directed to )
- text.yml - deployed using the pipeline-text.yml
- search.yml - deployed using the pipeline-search.yml
- windows/docker-api.yml - deployed using the pipeline-docker.yml 
- windows/python.yml - deployed using the pipeline-python.yml

Trigger these pipelines once you're happy with the base infrastructure and secrets. Private endpoints in front of the acr and frontend app may need to be disassociated for the push depending on your service principal permissions.

------------------------------

- We've also added the variable VITE_LOGO and VITE_BRANDED to remove kpmg branding from our sandbox environment, depending on your usecase set the variable to true in the pipeline.

- We've manually added the app configs for the frontend and api container and stored the variables mentioned above, these should be stored in a key vault and pulled into the resource. In the bicep deployment this will be saved automatically.

- Three containers have been saved within the cosmos db and set the ids as /id and /userid (containers = personas, ids and prompts)

- Add the cognitive services user identity to the api app
- Add the startup command to the frontend app
- Add the api User.Read permission and grant Admin consent so that the frontend app can authenicate the users using their bearer tokens

- **Naming convention** -

  Current: AUSAZDEV-KYMCT-RG01

  1. AU = location - Australia
  2. S = region - Sydney (Australia east)
  3. AZ = platform - Azure
  4. DEV = environment - Development
  5. KYMCT = project name (5 chars) = short for Kymchat
  6. RG01 = resource = resource group 1

- **VNET range** - If the client you're building has specific networking requirements, the solution may need to be alter to built within their spoke. This solution uses three vnets with the following ranges:

  1. /24 --> for resource deployment, each resource is vnet integrated and is behind a private endpoint
  2. /28 --> Used to host the virtual machine and pip
  3. /28 --> openai resource (currently hosted in our kymchat innovation subscriptions)

Current VNET range = 10.100.102.0/24

- _Private endpoints_
  - ACR = 10.100.102.36 & 10.100.102.37
  - APP01 = 10.100.102.38
  - Cosmos = 10.100.102.45
  - DL01 = 10.100.102.42
  - FA01 = 10.100.102.39
  - FA02 = 10.100.102.40
  - FA03 = 10.100.102.41
  - FR01 = 10.100.102.43
  - KV01 = 10.100.102.46