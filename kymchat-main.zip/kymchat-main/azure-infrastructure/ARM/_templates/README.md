<a name="readme-top"></a>

<!-- OUR PROJECT LOGO -->
<div align="center">
  <img src="/.github/images/KYM-assets003-07-200x133.png" alt="Logo">
  <h3 align="center">KymChat</h3>
</div>

# KymChat Global sandbox environments 

## Export of json templates

- export taken from sandbox environments with all code and config incase envs get deleted after 45 days. 

