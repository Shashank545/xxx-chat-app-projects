<a name="readme-top"></a>

<!-- OUR PROJECT LOGO -->
<div align="center">
  <img src="/.github/images/KYM-assets003-07-200x133.png" alt="Logo">
  <h3 align="center">KymChat</h3>
</div>

# ARM TEMPLATES - KymChat Azure Infrastructure Setup

**Templates:** ARM

## Azure Deployment

If you\'re wanting to deploy KymChat into your own environment please use the arm templates provided, both GitHub actions and ADO deployment methods are available. To deploy the infrastructure and application code through ADO, please use the files found within the _yaml/infra and _yaml/application folders.

| Description                           | Folder                                                 | Module                                                                                    |
| ------------------------------------- | ------------------------------------------------------ | ----------------------------------------------------------------------------------------- |
| ARM templates for resource deployment | `kymchat/azure-infrastructure/ARM`                     | https://github.com/KPMG-AU/kymchat/tree/main/azure-infrastructure/ARM                     |
| Infrastructure and application - Github actions pipelines              | `kymchat/.github/workflows/oneclick.yml`          | https://github.com/KPMG-AU/kymchat/blob/main/.github/workflows/oneclick.yml          |
| Infrastructure - ADO pipelines                         | `kymchat/azure-infrastructure/ARM/_yaml/infra/azure-pipelines.yml` | https://github.com/KPMG-AU/kymchat/blob/main/azure-infrastructure/ARM/_yaml/infra/azure-pipelines.yml |
| Application - ADO pipelines                         | `kymchat/azure-infrastructure/ARM/_yaml/application/*` | https://github.com/KPMG-AU/kymchat/blob/main/azure-infrastructure/ARM/_yaml/application/* |


- **Naming convention** -

  Current: AUSAZDEV-KYMCT-RG01

  1. AU = location - Australia
  2. S = region - Sydney (Australia east)
  3. AZ = platform - Azure
  4. DEV = environment - Development
  5. KYMCT = project name (5 chars) = short for Kymchat
  6. RG01 = resource = resource group 1

- **VNET range** - If the client you're building has specific networking requirements, the solution may need to be alter to built within their spoke. This solution uses three vnets with the following ranges:

  1. /24 --> for resource deployment, each resource is vnet integrated and is behind a private endpoint
  2. /28 --> Used to host the virtual machine and pip
  3. /28 --> openai resource (currently hosted in our kymchat innovation subscriptions)

Current VNET range = 10.100.102.0/24

- _Private endpoints_
  - ACR = 10.100.102.36 & 10.100.102.37
  - APP01 = 10.100.102.38
  - Cosmos = 10.100.102.45
  - DL01 = 10.100.102.42
  - FA01 = 10.100.102.39
  - FA02 = 10.100.102.40
  - FA03 = 10.100.102.41
  - FR01 = 10.100.102.43
  - KV01 = 10.100.102.46
 
## Resources

![Image](/.github/images/azure-infrastructure.png?raw=true)    
