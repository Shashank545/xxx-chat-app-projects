# README

This repository documents the results of experiments conducted on the design of Chat KOMEI, a Retrieval Augmented Generation solution aimed at answering auditor questions.
