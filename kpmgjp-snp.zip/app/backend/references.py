"""References building logic."""

def build_references(r: any) -> any:
    """
    Add to the response dictionary a key / value pair for citations.
    The key is "citations" and the value is a list of tuples of format
    (i, tag, href), where i is an integer, and tag and href are strings
    representing respectively the tag and the hyperlink of the reference.
    """
    references = set((point["link_tag"], point["link_href"]) for point in r["data_points"])
    r["references"]=[(i+1, x[0], x[1]) for (i, x) in enumerate(references)]
    return r
