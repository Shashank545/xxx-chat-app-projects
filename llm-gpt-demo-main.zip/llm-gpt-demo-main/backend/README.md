# LLM-GPT-Backend-Demo


## Commands

Install packages

`pip install -r requirements.txt`

Run the application

`uvicorn --app-dir=./app main:app --reload`